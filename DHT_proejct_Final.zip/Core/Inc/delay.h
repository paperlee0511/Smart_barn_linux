

#ifndef INC_DELAY_H_
#define INC_DELAY_H_



#include "tim.h"

void delay_10(uint16_t us);
void delay_11(uint16_t us);


#endif /* INC_DELAY_H_ */
